#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../headers/common.h"

/**
 * @brief Trouver le minimum entre 3 entiers.
 */
int min3(int a, int b, int c) {
    int min = a;
    if (b < min) min = b;
    if (c < min) min = c;
    return min;
}


/**
 * @brief Calcule la distance de Levenshtein entre deux mots.
 * Cette fonction mesure la similarité entre deux chaînes de caractères.
 * Elle représente le nombre minimum d'opérations (insertion, suppression, 
 * substitution) nécessaires pour transformer le 'mot1' en 'mot2'.
 */
int distance(const char *word1, const char *word2) {
    
    int len1 = strlen(word1);
    int len2 = strlen(word2);

    int matrix[len1 + 1][len2 + 1];

    // Initialisation première colonne (0, 1, 2, ...)
    for (int i = 0; i <= len1; i++) {
        matrix[i][0] = i;
    }

    // Initialisation première ligne (0, 1, 2, ...)
    for (int j = 0; j <= len2; j++) {
        matrix[0][j] = j;
    }

    // Remplir la matrice
    for (int i = 1; i <= len1; i++) {
        for (int j = 1; j <= len2; j++) {
            
            int cost;
            if (word1[i - 1] == word2[j - 1]) {
                cost = 0; // identique, pas de changement
            } else {
                cost = 1; // différent, un remplacement
            }

            // Coût des 3 opérations possibles et on garde le minimum
            matrix[i][j] = min3(
                matrix[i - 1][j] + 1,         // Suppression
                matrix[i][j - 1] + 1,         // Insertion
                matrix[i - 1][j - 1] + cost   // Remplacement (ou rien si cost=0)
            );
        }
    }

    return matrix[len1][len2];
}