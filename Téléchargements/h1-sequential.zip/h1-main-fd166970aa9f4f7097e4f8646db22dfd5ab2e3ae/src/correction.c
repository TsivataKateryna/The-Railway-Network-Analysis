#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../headers/common.h"
#include "../headers/dict.h"
#include "../headers/distance.h"
#include "../headers/detection.h"
#include "../headers/meilleurdico.h"
#include "../headers/pretty_print.h"


/**
 * @brief Parcourt le dictionnaire pour trouver le mot le plus proche.
 */
char* suggerer_correction(const char *mot_faux, Dictionary_t *dict) {
    if (dict == NULL || dict->word_count == 0) return NULL;

    int min_dist = 999999;
    char *meilleur_mot = NULL;

    for (size_t i = 0; i < dict->word_count; i++) {
        
        int score_actuel = distance(mot_faux, dict->words[i]);

        // On compare avec celui gardé pour l'instant
        if (score_actuel < min_dist) {
            min_dist = score_actuel;
            meilleur_mot = dict->words[i];
        }

        // Optimisation : Si la distance est de 1, on ne trouvera pas mieux
        // car 0 voudrait dire que c'est le même mot, or on sait qu'il est faux
        if (min_dist == 1) {
            break; 
        }
    }

    return meilleur_mot;
}


/**
 * @brief Gère la correction sur l'ensemble du texte et s'occupe de l'affichage.
 */
void corriger_texte(char **lines, size_t line_count, Dictionary_t *dicts, size_t dicts_count) {
    for (size_t i = 0; i < line_count; i++) {
        Dictionary_t *meilleur_dico = trouver_meilleur_dico(lines[i], dicts, dicts_count);

        uint32_t positions[500];
        char *corrections[500];
        
        char *copie_phrase = strdup(lines[i]);
        if (!copie_phrase) continue;

        char *separateurs = " .,;!?\n\r()\"";
        char *mot = strtok(copie_phrase, separateurs);
        
        int count = 0;
        int word_index = 0;
        while (mot != NULL) {
            if (is_word_in_dict(mot, meilleur_dico) == 0) {
                
                positions[count] = word_index;
                // On utilise la fonction de correction pour trouver le meilleur remplacement
                corrections[count] = suggerer_correction(mot, meilleur_dico);
                
                count++;
            }
            mot = strtok(NULL, separateurs);
            word_index++;
        }

        pretty_print_correction(lines[i], i, count, positions, corrections);
        free(copie_phrase);
    }
}