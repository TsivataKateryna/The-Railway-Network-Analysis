#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "../headers/common.h"
#include "../headers/dict.h"
#include "../headers/detection.h"


/**
 * @brief On cherche le dictionnaire qui génère le moins de fautes.
 */
Dictionary_t* trouver_meilleur_dico(char *ligne, Dictionary_t *dicts, size_t dicts_count) {
    if (dicts_count == 0) return NULL;

    int min_fautes = 999999;
    Dictionary_t *meilleur_dico = &dicts[0];
    
    uint32_t positions[500]; 

    for (size_t i = 0; i < dicts_count; i++) {
        // On compte les fautes avec le dictionnaire numéro 'i'
        int fautes_actuelles = nbr_fautes(ligne, &dicts[i], positions);
        
        // On compare pour trouver le meilleur dictionnaire
        if (fautes_actuelles < min_fautes) {
            min_fautes = fautes_actuelles;
            meilleur_dico = &dicts[i];
        }
    }

    return meilleur_dico;
}