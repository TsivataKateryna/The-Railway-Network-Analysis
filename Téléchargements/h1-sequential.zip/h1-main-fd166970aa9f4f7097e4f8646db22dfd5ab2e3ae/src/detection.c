#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "../headers/common.h"
#include "../headers/dict.h"
#include "../headers/distance.h"
#include "../headers/meilleurdico.h"
#include "../headers/pretty_print.h"


/**
 * @brief Vérifie si un mot existe exactement dans le dictionnaire.
 */
int is_word_in_dict(const char *word, Dictionary_t *dict) {
    for (int i = 0; i < dict->word_count; i++) {
        if (strcmp(word, dict->words[i]) == 0) {
            return 1;
        }
    }
    return 0;
}


/**
 * @brief Détecte les erreurs pour une seule phrase, retiens les positions et renvoie le nombre total d'erreur.
 */
int nbr_fautes(char *phrase, Dictionary_t *dict, uint32_t *positions) {
    if (phrase == NULL || strlen(phrase) == 0) return 0;

    // On travaille sur une copie pour laisser l'original intact pour l'affichage
    char *copie_phrase = strdup(phrase);
    if (!copie_phrase) return 0;

    char *separateurs = " .,;!?\n\r";
    char *mot = strtok(copie_phrase, separateurs);
    
    int count = 0;
    int word_index = 0;
    while (mot != NULL) {
        if (is_word_in_dict(mot, dict) == 0) {
            positions[count] = word_index;
            count++;
        }
        mot = strtok(NULL, separateurs);
        word_index++;
    }

    free(copie_phrase);
    return count;
}


/**
 * @brief Gère tout le processus de détection pour un texte complet.
 */
void nbr_fautes_texte(char **lines, size_t line_count, Dictionary_t *dict, size_t dicts_count) {
    for (size_t i = 0; i < line_count; i++) {
        Dictionary_t *meilleur_dico = trouver_meilleur_dico(lines[i], dict, dicts_count);

        uint32_t positions[500];
        
        int nb = nbr_fautes(lines[i], meilleur_dico, positions);
        pretty_print_detection(lines[i], i, nb, positions);
    }
}