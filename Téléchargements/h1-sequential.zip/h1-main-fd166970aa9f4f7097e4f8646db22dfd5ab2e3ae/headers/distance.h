#ifndef DISTANCE_H
#define DISTANCE_H

/**
 * @brief Calcule le minimum entre trois entiers.
 * @param a Premier entier.
 * @param b Deuxième entier.
 * @param c Troisième entier.
 * @return L'entier ayant la plus petite valeur parmi a, b et c.
 */
int min3(int a, int b, int c);

/**
 * @brief Calcule la distance de Levenshtein entre deux mots.
 * @param word1 La première chaîne de caractères (généralement le mot erroné).
 * @param word2 La deuxième chaîne de caractères (généralement un mot du dictionnaire).
 * @return Le score de distance sous forme d'entier (0 si les mots sont identiques).
 */
int distance(const char *word1, const char *word2);

#endif