#ifndef CORRECTION_H
#define CORRECTION_H

#include "dict.h"
#include <stddef.h>

/**
 * @brief Parcourt le dictionnaire pour trouver le mot le plus proche (Distance de Levenshtein).
 * @param mot_faux Le mot mal orthographié détecté dans le texte.
 * @param dict Le dictionnaire de référence utilisé pour chercher des suggestions.
 * @return Un pointeur vers le mot du dictionnaire qui a le meilleur score (la plus petite distance).
 */
char* suggerer_correction(const char *mot_faux, Dictionary_t *dict);

/**
 * @brief Gère la correction sur l'ensemble du texte et affiche les suggestions.
 * @param lines Tableau contenant toutes les lignes du fichier d'entrée.
 * @param line_count Le nombre total de lignes.
 * @param dicts Le pointeur vers les dictionnaires chargés.
 * @param dicts_count Le nombre total de dictionnaires.
 */
void corriger_texte(char **lines, size_t line_count, Dictionary_t *dicts, size_t dicts_count);

#endif