#ifndef MEILLEURDICO_H
#define MEILLEURDICO_H

#include "dict.h"
#include <stddef.h>

/**
 * @brief On cherche le dictionnaire qui génère le moins de fautes.
 * @param ligne La phrase à analyser.
 * @param dicts Le tableau contenant tous les dictionnaires.
 * @param dicts_count Le nombre total de dictionnaires.
 * @return Un pointeur vers le meilleur dictionnaire.
 */
Dictionary_t* trouver_meilleur_dico(char *ligne, Dictionary_t *dicts, size_t dicts_count);

#endif