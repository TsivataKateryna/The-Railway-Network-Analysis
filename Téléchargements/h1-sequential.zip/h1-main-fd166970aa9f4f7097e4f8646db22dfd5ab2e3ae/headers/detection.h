#ifndef DETECTION_H
#define DETECTION_H

#include <stdint.h>
#include <stddef.h>
#include "dict.h"

/**
 * @brief Vérifie si un mot est présent dans le dictionnaire.
 * @param word Le mot à chercher.
 * @param dict Le dictionnaire de référence.
 * @return 1 si trouvé, 0 sinon.
 */
int is_word_in_dict(const char *word, Dictionary_t *dict);

/**
 * @brief Analyse une phrase pour compter les fautes et noter leurs positions.
 * @param phrase La chaîne de caractères à analyser.
 * @param dict Le dictionnaire pour la vérification.
 * @param positions Tableau (alloué par l'appelant) pour stocker les offsets des erreurs.
 * @return Le nombre total de fautes détectées dans la phrase.
 */
int nbr_fautes(char *phrase, Dictionary_t *dict, uint32_t *positions);

/**
 * @brief Gère la détection sur l'ensemble du texte et s'occupe de l'affichage en couleur.
 * @param lines Tableau contenant toutes les lignes du fichier d'entrée.
 * @param line_count Le nombre total de lignes dans le tableau.
 * @param dicts Le pointeur vers les dictionnaires chargés en mémoire.
 * @param dicts_count Le nombre total de dictionnaires.
 */
void nbr_fautes_texte(char **lines, size_t line_count, Dictionary_t *dicts, size_t dicts_count);

#endif