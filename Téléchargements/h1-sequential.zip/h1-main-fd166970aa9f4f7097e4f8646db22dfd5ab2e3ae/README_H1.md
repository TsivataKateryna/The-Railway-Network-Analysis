# Déscription des fichiers avec fonctions et rôle
## src

detection : trouver les erreurs dans un texte

    is_word_in_dict : renvoit 1 si le mot se trouve dans un dictionnaire, 0 sinon

    nbr_fautes : renvoit le nombre d'erreurs dans une phrase en faisant appel à is_word_in_dict

    nbr_fautes_texte : trouve les fautes dans un texte complet en faisant appel à nbr_fautes et à trouver_meilleur_dico (voir en-dessous) et print le texte en affichant les mots erronés en rouge grâce à la fonction fournie pretty_print_detection.


meilleurdico : trouver la langue du texte

    trouver_meilleur_dico : trouve le meilleur dictionnaire en comptant le nombre d'eurreurs dans la première phrase et le renvoit.

correction : 

    suggerer_correction : parcourt le dictionnaire et retourne le meilleur mot qui corrigerait le mot erroné grâce à la fonction distance qui renvoie la distance entre deux mots (voir en-dessous).

    corriger_texte : corrige toutes les erreurs d'un texte et l'affiche en mettant le mot erroné en rouge et la correction en vert grâce à la fonction fournie prettty_print_correction.


distance : 

    distance : calcule la distance de Levenshtein entre deux mots, c'est-à-dire la similarité entre deux chaînes de caractères (nombre minimum d'opérations (insertion, suppression, substitution) nécessaires pour transformer le 'mot1' en 'mot2') en appelant min3 (voir en-dessous).

    min3 : renvoie le minmum de 3 entier (fonction nécessaire pour calculer une distance de Levenshtein)


## tests

test_detection : 

    série de tests qui vérifient une bonne détection des mots erronés en français.

test_meilleurdico : 

    série de tests qui vérifient une bonne détermination de la langue d'une phrase (un test pas fonctionnel pour l'instant).

test_correction : 

    série de tests qui vérifient si la correction des mots s'effectue correctement.

test_distance : 

    série de tests qui vérifient si la distance entre deux mots est correcte.

main:

    fonction qui compile tous les tests ci-dessus.

# Commandes de lancement des programmes

Afficher les phrases où les erreurs sont détectées et mises en évidence en rouge : 

    make
    ./spellchecker --mode detection 

Afficher les phrases où les erreurs sont mises en évidence en rouge et leur proposition de correction est affichée en vert:

    make
    ./spellchecker --mode correction

Compiler les tests : 

    make test 
    ./test