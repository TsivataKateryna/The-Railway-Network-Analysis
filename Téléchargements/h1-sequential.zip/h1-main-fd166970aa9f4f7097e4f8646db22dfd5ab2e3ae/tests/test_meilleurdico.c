#include <CUnit/Basic.h>
#include <CUnit/CUnit.h>

#include <stdio.h>
#include "common.h"
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <getopt.h>
#include "test_meilleurdico.h"
#include "meilleurdico.h"

void test_meilleurdico (void){
    // les dicos
    size_t dicts_count = 0;
    Dictionary_t *dicts = NULL;
    //Dictionary_t * dicts = (Dictionary_t *) malloc(sizeof(Dictionary_t)*);
    load_dictionaries(0, &dicts, &dicts_count);

    // les phrases
    char* str_1 = "phrase en français";
    char* str_2 = "sentence in english";
    char* str_3 = "fråze è walon";

    Dictionary_t * meilleur_dico1 = trouver_meilleur_dico(str_1,dicts,dicts_count);
    Dictionary_t * meilleur_dico2 = trouver_meilleur_dico(str_2,dicts,dicts_count);
    Dictionary_t * meilleur_dico3 = trouver_meilleur_dico(str_3,dicts,dicts_count);

    //printf("%s",meilleur_dico2->lang);
    CU_ASSERT_EQUAL(strcmp(meilleur_dico1->lang,"fr"),0); // ce test le fonctionne pas
    CU_ASSERT_EQUAL(strcmp(meilleur_dico2->lang,"en"),0);
    CU_ASSERT_EQUAL(strcmp(meilleur_dico3->lang,"wa"),0);
}