#ifndef TEST_DISTANCE_H
#define TEST_DISTANCE_H

#include <CUnit/Basic.h>
#include <CUnit/CUnit.h>

#include <stdio.h>
#include "common.h"
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <getopt.h>

/**
 * test la valeurs de la distance entre des mots
 */
void test_distance();

#endif