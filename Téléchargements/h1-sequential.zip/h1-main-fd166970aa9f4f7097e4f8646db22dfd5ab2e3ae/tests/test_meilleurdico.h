#ifndef TEST_MEILLEURDICO_H
#define TEST_MEILLEURDICO_H

#include <CUnit/Basic.h>
#include <CUnit/CUnit.h>

#include <stdio.h>
#include "common.h"
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <getopt.h>

/**
 * test le choix du meilleur dictionnaire
 */
void test_meilleurdico (void);

#endif