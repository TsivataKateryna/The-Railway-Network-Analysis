#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include "../headers/common.h"
#include "../headers/dict.h"      
#include "../headers/correction.h" 

#include "test_correction.h"

#include <CUnit/Basic.h>
#include <CUnit/CUnit.h>

void test_correction() {

    // 1. création structure Dictionary_t pour le dico français
    Dictionary_t dico_fr;
    dico_fr.words = (char**)DICTIONARIES[1]; // Le tableau de mots FR
    dico_fr.word_count = DICT_SIZES[1];      // La taille du dictionnaire FR

    //mot correct
    char* str_1 = "bonjour";
    char* corrigé_1 = suggerer_correction(str_1, &dico_fr);
    CU_ASSERT_EQUAL(strcmp(corrigé_1,"bonjour"),0);

    //il manque une lettre
    char* str_2 = "bojour";
    char* corrigé_2 = suggerer_correction(str_2, &dico_fr);
    CU_ASSERT_EQUAL(strcmp(corrigé_2,"bonjour"),0);

    //mauvaise lettre
    char* str_3= "bonour";
    char* corrigé_3 = suggerer_correction(str_3, &dico_fr);
    CU_ASSERT_EQUAL(strcmp(corrigé_3,"bonjour"),0);
 
}