#ifndef TEST_CORRECTION_H
#define TEST_CORRECTION_H

#include <CUnit/Basic.h>
#include <CUnit/CUnit.h>

#include <stdio.h>
#include "common.h"
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <getopt.h>

/**
 * test la correcton de différents mots
 */
void test_correction ();

#endif