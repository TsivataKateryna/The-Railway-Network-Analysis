#include <CUnit/Basic.h>
#include <CUnit/CUnit.h>

#include <stdio.h>
#include "common.h"
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <getopt.h>
#include "test_distance.h"
#include "distance.h"

void test_distance(void) {
    CU_ASSERT(distance("bonjour", "bonjour") == 0);
    CU_ASSERT(distance("", "lettre") == 6);
    CU_ASSERT(distance("mot", "") == 3);
    CU_ASSERT(distance("code", "cade") == 1);
    CU_ASSERT(distance("table", "tables") == 1);
    CU_ASSERT(distance("parler", "parle") == 1);
    CU_ASSERT(distance("un", "le") == 2);
    CU_ASSERT(distance("plante", "chante") == 3);
    CU_ASSERT(distance("test", "un") == 4);
    CU_ASSERT(distance("Vélo", "velo") == 2);
    CU_ASSERT(distance("a", "b") == 1);
    CU_ASSERT(distance("a", "a") == 0);
    CU_ASSERT(distance("a", "alphabet") == 7);
}