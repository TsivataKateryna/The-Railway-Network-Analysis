#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include "../headers/common.h"
#include "../headers/dict.h"      
#include "../headers/detection.h" 

#include <CUnit/Basic.h>
#include <CUnit/CUnit.h>

void test_detection() {

    // 1. On crée une structure Dictionary_t pour le test
    // On va tester avec le dictionnaire français (index 1 dans ton dict.h)
    Dictionary_t mon_dico_fr;
    mon_dico_fr.words = (char**)DICTIONARIES[1]; // Le tableau de mots FR
    mon_dico_fr.word_count = DICT_SIZES[1];      // La taille du dictionnaire FR

    uint32_t positions[100];

    // 2. Test 1 : Phrase ok en Francais
    char phrase1[] = "le chat mange"; 
    int nb1 = nbr_fautes(phrase1, &mon_dico_fr, positions);
    CU_ASSERT_EQUAL(nb1,0);

    // 3. Test 2 : Phrase avec 1 faute
    char phrase2[] = "le chst hhange"; // "chst" et "hhange" existent pas
    int nb2 = nbr_fautes(phrase2, &mon_dico_fr, positions);
    CU_ASSERT_EQUAL(nb2,2);
    CU_ASSERT_EQUAL(positions[0],1); // "chst" mot en position 1

    char phrase3[] = "le chst minge"; 
    int nb3 = nbr_fautes(phrase3, &mon_dico_fr, positions);
    CU_ASSERT_EQUAL(nb3,2); // le code identifie bien 2 fautes 
}
