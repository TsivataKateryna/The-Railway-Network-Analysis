#ifndef TEST_DETECTION_H
#define TEST_DETECTION_H

#include <CUnit/Basic.h>
#include <CUnit/CUnit.h>

#include <stdio.h>
#include "common.h"
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <getopt.h>

/**
 * test la detection des erreurs dans des phrases différentes
 */
void test_detection ();

#endif