%%% Agent Blank Module
%%% A simple random-movement snake agent template.
%%% This agent moves randomly and tracks other bots in the game.

functor

import
    OS
    Input
export
    'getPort': SpawnAgent
define

    % Mapping from random numbers (1-4) to cardinal directions
    Directions = directions(
        1: 'north'
        2: 'south'
        3: 'east'
        4: 'west'
    )

    % NextMove: Calculates the next position given current state and direction.
    % Inputs:
    %   - State: Current agent state record with 'x' and 'y' coordinates
    %   - Dir: Direction atom ('north', 'south', 'east', 'west')
    % Output: Record m('x':NewX 'y':NewY) representing the new position
    fun {NextMove State Dir}
        I
    in
        case Dir
        of 'north' then I = (State.y - 1)*Input.dim+State.x+1 m('x':State.x 'y':State.y-1)
        [] 'south' then I = (State.y + 1)*Input.dim+State.x+1 m('x':State.x 'y':State.y+1)
        [] 'east' then I = State.y*Input.dim+(State.x+1)+1 m('x':State.x+1 'y':State.y)
        [] 'west' then I = State.y*Input.dim+(State.x-1)+1 m('x':State.x-1 'y':State.y)
        else 0
        end
    end

   fun {CellIndex X Y}
      Y*Input.dim + X + 1
   end

   fun {GetCell Map X Y}
      Map.{CellIndex X Y}
   end

   fun {IsWall Map X Y}
      {GetCell Map X Y} == 1
   end

   fun {FrontPos X Y Dir}
      case Dir
      of 'north' then X#(Y-1)
      [] 'south' then X#(Y+1)
      [] 'east'  then (X+1)#Y
      [] 'west'  then (X-1)#Y
      end
   end

   fun {TurnRight D}
      case D
      of 'north' then 'east'
      [] 'east'  then 'south'
      [] 'south' then 'west'
      [] 'west'  then 'north'
      end
   end

   fun {TurnLeft D}
      case D
      of 'north' then 'west'
      [] 'west'  then 'south'
      [] 'south' then 'east'
      [] 'east'  then 'north'
      end
   end

   fun {AbsDiff A B}
      if A>=B then A-B else B-A end
   end

   fun {IndexToPos I}
      X = (I-1) mod Input.dim
      Y = (I-1) div Input.dim
   in
      X#Y
   end

    fun {ClosestFruit Map SnakeX SnakeY}
        fun {Scan L I BestIndex BestDist}
            case L
            of H|T then
                if H == 2 then
                    local FX FY DX DY D in
                        FX#FY = {IndexToPos I}
                        DX = {AbsDiff FX SnakeX}
                        DY = {AbsDiff FY SnakeY}
                        D  = DX + DY

                        if D < BestDist then
                            {Scan T I+1 I D}
                        else
                            {Scan T I+1 BestIndex BestDist}
                        end
                    end
                else
                    {Scan T I+1 BestIndex BestDist}
                end
            [] nil then BestIndex
            end
        end
    in
        {Scan Map 1 ~1 9999}
    end


    % Agent: Main agent function implementing the behavior loop.
    % Input: State - Current agent state containing id, map, gcport, dir, x, y, tracker, port
    % Output: Function that processes messages and returns updated agent instance
    % State attributes:
    %   - id: Unique agent identifier
    %   - map: Game map (list of integers)
    %   - gcport: Port to the Game Controller
    %   - dir: Current direction ('north', 'south', 'east', 'west', 'stopped')
    %   - x, y: Current grid coordinates
    %   - tracker: Record tracking other bots
    %   - port: This agent's communication port
    fun {Agent State}

        % MovedTo: Handles the movedTo message when this bot moves.
        % Input: movedTo(Id _ X Y) message
        %   - Id: Bot identifier that moved
        %   - _: Bot type ('snake')
        %   - X, Y: New grid coordinates
        % Output: Updated agent instance
        fun {MovedTo movedTo(Id _ X Y)}
            Next TempState NewTracker NewDir
        in
            if Id == State.id then
                TempState = {Adjoin State state('x':X 'y':Y)}

                local 
                    TryDir FX FY Fx Fy FruitIndex 
                    TempState1 TempState2
                in
                    TryDir = State.dir
                    if TryDir == 'stopped' then
                        TryDir = 'north'
                    end

                    NewTracker = State.tracker

                    FruitIndex = {ClosestFruit State.map State.x State.y}

                    if FruitIndex \= ~1 andthen ({OS.rand} mod 5) \= 0 then
                        FX#FY = {IndexToPos FruitIndex}

                        if FX > State.x then
                            TryDir = 'east'
                        elseif FX < State.x then
                            TryDir = 'west'
                        elseif FY > State.y then
                            TryDir = 'south'
                        elseif FY < State.y then
                            TryDir = 'north'
                        end
                    else
                        TryDir = Directions.({OS.rand} mod 4 + 1)
                    end

                    Fx#Fy = {FrontPos State.x State.y TryDir}

                    if {IsWall State.map Fx Fy} then
                        TryDir = {TurnRight TryDir}
                        Fx#Fy = {FrontPos State.x State.y TryDir}

                        if {IsWall State.map Fx Fy} then
                            TryDir = {TurnLeft TryDir}
                        end
                    end

                    NewDir = TryDir

                    Next = {NextMove TempState NewDir}
                    {Send State.gcport moveTo(State.id NewDir)}

                    TempState1 = {AdjoinAt TempState 'dir' NewDir}
                    TempState2 = {AdjoinAt TempState1 'tracker' NewTracker}

                    {Agent TempState2}
                end

            else
                NewTracker = State.tracker
                {Agent {AdjoinAt State 'tracker' NewTracker}}
            end
        end

    in
        % Message dispatcher function
        fun {$ Msg}
            Dispatch = {Label Msg}
            Interface = interface(
                'movedTo': MovedTo
            )
        in
            if {HasFeature Interface Dispatch} then
                {Interface.Dispatch Msg}
            else
                {Agent State}
            end
        end
    end

    % Handler: Processes messages from the stream and updates agent instance.
    % Inputs:
    %   - Msg | Upcoming: Stream pattern with current message and remaining stream
    %   - Instance: Current agent instance (function)
    % Output: None (recursive procedure)
    % Note: Msg | Upcoming is a pattern match of the Stream argument
    proc {Handler Msg | Upcoming Instance}
        if Msg \= shutdown() then {Handler Upcoming {Instance Msg}} end
    end

    % SpawnAgent: Creates and initializes a new agent instance.
    % Input: init(Id GCPort Map) record
    %   - Id: Unique agent identifier
    %   - GCPort: Port to the Game Controller
    %   - Map: Game map as a list
    % Output: Port for communicating with the agent
    fun {SpawnAgent init(Id GCPort Map)}
        Stream
        Port = {NewPort Stream}

        Instance = {Agent state(
            'id': Id
            'map': Map
            'gcport': GCPort
            'dir':'stopped'
            'x':~1
            'y':~1
            'tracker':tracker()
            'port':Port
        )}
    in
        thread {Handler Stream Instance} end
        Port
    end
end
