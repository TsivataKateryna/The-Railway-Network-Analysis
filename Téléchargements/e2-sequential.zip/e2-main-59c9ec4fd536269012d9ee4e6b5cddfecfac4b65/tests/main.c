#include <CUnit/CUnit.h>
#include <CUnit/Basic.h>
#include "../headers/detect.h"

void add_word_test(void) {
    Words words;
    words.words = NULL;
    words.size = 0;
    char* word;

    CU_ASSERT(words.size == 0);
    word = "coucou";
    words = add_word(words, word);
    CU_ASSERT(words.size == 1);
    CU_ASSERT(strcmp(words.words[0], word) == 0);
    word = "deuxieme";
    CU_ASSERT(words.size == 1);
    words = add_word(words, word);
    CU_ASSERT(words.size == 2);
    CU_ASSERT(strcmp(words.words[1], word) == 0);
    CU_ASSERT(strcmp(words.words[0], "coucou") == 0);

    free_Words(words);
}

void parse_line_test(void) {
    char* line;
    Words parsed_line;

    line = "";
    parsed_line = parse_line(line, 0);
    CU_ASSERT(parsed_line.size == 0);

    line = "fesfse";
    parsed_line = parse_line(line, 1);
    CU_ASSERT(strcmp(parsed_line.words[0], "fesfse") == 0);
    CU_ASSERT(parsed_line.size == 1);

    line = "fesiu fesd";
    parsed_line = parse_line(line, 2);
    CU_ASSERT(strcmp(parsed_line.words[0], "fesiu") == 0);
    CU_ASSERT(strcmp(parsed_line.words[1], "fesd") == 0);
    CU_ASSERT(parsed_line.size == 2);

    free_Words(parsed_line);
}


Dictionary_t fr = {
    .words = (char*[]){"bonjour", "chien", "lettre", "lila", "mot", "table", "tard"},
    .word_count = 7,
    .lang = "fr",
    .id = 1
};

Dictionary_t de = {
    .words = (char*[]){"Haus", "Zug", "hallo", "spät"},
    .word_count = 4,
    .lang = "de",
    .id = 2
};

void check_if_in_dict_test(void) {
    CU_ASSERT_EQUAL(check_if_in_dict("bonjour", &fr), true);
    CU_ASSERT_EQUAL(check_if_in_dict("chien", &fr), true);
    CU_ASSERT_EQUAL(check_if_in_dict("pizza", &fr), false);
    CU_ASSERT_EQUAL(check_if_in_dict("lagon", &fr), false);
    CU_ASSERT_EQUAL(check_if_in_dict("lettre", &fr), true);
    CU_ASSERT_EQUAL(check_if_in_dict("dbaekf", &fr), false);
    CU_ASSERT_EQUAL(check_if_in_dict("mot", &fr), true);
}

void detection_test(void) {
    LineErrors line_errors;
    char* line;
    int line_size;

    line = "";
    line_size = 0;
    line_errors = detection(line, line_size, &fr);
    // printf("size : %zu\n", line_errors.size);
    // printf("lang : %s\n", line_errors.dict -> lang);
    CU_ASSERT(line_errors.size == 0);
    CU_ASSERT(strcmp(line_errors.dict -> lang, "fr") == 0);

    line = "chien grece";
    line_size = 2;
    line_errors = detection(line, line_size, &fr);
    CU_ASSERT(line_errors.size == 1);
    CU_ASSERT(strcmp(line_errors.dict -> lang, "fr") == 0);
    CU_ASSERT(strcmp(line_errors.bad_words[0].word, "grece") == 0);
    line_errors = detection(line, line_size, &de);
    CU_ASSERT(line_errors.size == 2);
    CU_ASSERT(strcmp(line_errors.dict -> lang, "de") == 0);
    CU_ASSERT(strcmp(line_errors.bad_words[0].word, "chien") == 0);
    CU_ASSERT(strcmp(line_errors.bad_words[1].word, "grece") == 0);

}

int main(void) {
    CU_initialize_registry();

    CU_pSuite suite_parsing = CU_add_suite("Word parsing", 0, 0);
    CU_add_test(suite_parsing, "Add word test", add_word_test);
    CU_add_test(suite_parsing, "Parse line test", parse_line_test);

    CU_pSuite suite_detection = CU_add_suite("Detection", 0, 0);
    CU_add_test(suite_detection, "Detection test in dict", check_if_in_dict_test);
    CU_add_test(suite_detection, "Detection test", detection_test);

    CU_basic_run_tests();
    CU_cleanup_registry();
    return 0;
}