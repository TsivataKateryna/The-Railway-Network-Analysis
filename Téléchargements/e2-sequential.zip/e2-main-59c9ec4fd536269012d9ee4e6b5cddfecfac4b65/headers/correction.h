#ifndef CORRECTION_H
#define CORRECTION_H

int levenshtein(const char *s1, const char *s2);

const char *mot_corrige(char *mot, Dictionary_t *dict);

#endif