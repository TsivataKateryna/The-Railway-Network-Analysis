#ifndef DETECT_H
#define DETECT_H
#include <stdlib.h>
#include <string.h>
#include "common.h"

/**
    @struct to contain all the words
*/
typedef struct {
    char** words;
    size_t size;
} Words;

/**
    @param words Words struct to free
*/
void free_Words(Words words);

/**
    @param words Words struct with all words
    @param word char* word to add
    @return Words struct with all words + word
**/
Words add_word(Words words, char* word);

/**
  @param line pointer to the line to be parsed
  @param line_size int of the size of the line (=word count)
  @return an array to contains the line parsed in words
**/
Words parse_line(char *line, int line_size);

/**
    @struct to contain the badword and its index
*/
typedef struct {
    char* word;
    int index;
} BadWord;

/**
    @param bad_word BadWord to be freed
*/
void free_BadWord(BadWord bad_word);

/**
    @struct to contain all badwords and associated dictionary
*/
typedef struct {
    BadWord* bad_words;
    size_t size;
    Dictionary_t* dict;
} LineErrors;

/**
    @param line_errors LineErrors to be freed
*/
void free_LineErrors(LineErrors line_errors);

/**
    @param word char* containing word to check
    @param dict Dictionary_t containing all the words from dictionary
    @return bool whether the word in the dict
*/
int cmp(const void *a, const void *b);
bool check_if_in_dict(const char *word, Dictionary_t *dict);

/**
    @param 
    @return LineError struct with all the wronly written words
*/
LineErrors detection(char* line, int line_size, Dictionary_t* dict);

#endif