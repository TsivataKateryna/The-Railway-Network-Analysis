#include <limits.h>
#include <dict.h>
#include <common.h>
#include <io.h>
#include <input.h>
#include <portable_endian.h>

int levenshteinDistance(const char *s1, const char *s2) {
    int len1 = strlen(s1);
    int len2 = strlen(s2);
    int matrix[len1 + 1][len2 + 1];

    for (int i = 0; i <= len1; i++) matrix[i][0] = i;
    for (int j = 0; j <= len2; j++) matrix[0][j] = j;

    for (int i = 1; i <= len1; i++) {
        for (int j = 1; j <= len2; j++) {
            int cost = (s1[i - 1] == s2[j - 1]) ? 0 : 1;
            int deletion = matrix[i - 1][j] + 1;
            int insertion = matrix[i][j - 1] + 1;
            int substitution = matrix[i - 1][j - 1] + cost;
            int min = deletion < insertion ? deletion : insertion;
            matrix[i][j] = min < substitution ? min : substitution;
        }
    }
    return matrix[len1][len2];
}

// Correction d'un mot en parcourant le dictionnaire jusqu'à NULL


/**
   @ param word Word that is incorrect
   @ param dictionnary[] Most suitable dictionnary 
   @ return Best correct word, given by the nearest distance withe the incorrect word, using 
                  the Levenshtein Distance 
 **/

const char* correct_word(const char* word, const char* dictionary[]) {
    int min_dist = 1000;
    const char* best = word;

    for (size_t i = 0; dictionary[i] != NULL; i++) {
        int dist = levenshtein(word, dictionary[i]);
        if (dist < min_dist) {
            min_dist = dist;
            best = dictionary[i];
        }
    }
    return best;
}



/**
   @ param errors Given output by the file detect.c 
   
**/

char* mot_corrige (char* mot, Dictionary_t* dict) {
    int dist = INT_MAX;
    char* nouveau_mot = NULL;
    for (int i = 0; i < dict -> word_count; i++) {
        if (strlen(dict -> words[i]) >= strlen(mot) - 3 && strlen(dict -> words[i]) <= strlen(mot) + 3) {
            if (levenshteinDistance(mot, dict -> words[i]) <= dist) {
                dist = levenshteinDistance(mot, dict -> words[i]);
                strcpy(nouveau_mot, dict -> words[i]);
            } 
        }
    }

    return nouveau_mot;
}