#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../headers/dict.h"
#include "../headers/io.h"

// Prototype pour la fonction de comptage d'erreurs
int count_incorrect_words(const char* line, const char* dict[], int dict_size) {return 0;};

// Nouvelle version de find_best_dictionary
int find_best_dictionary(const char* line, const char** dicts[], const int dict_sizes[], int nb_dicts, int* min_errors_out) {
    int best_index = -1;
    int min_errors = INT_MAX;

    for (int i = 0; i < nb_dicts; i++) {
        int errors = count_incorrect_words(line, dicts[i], dict_sizes[i]); // <--- correction ici
        if (errors < min_errors) {
            min_errors = errors;
            best_index = i;
        }
    }

    if (min_errors_out != NULL) {
        *min_errors_out = min_errors;
    }

    return best_index;
}

// int main() {
//     // Tableau de pointeurs vers les dictionnaires
//     const char** dicts[] = {
//         DICTIONARY_HIDDEN_0
//         // DICTIONARY_HIDDEN_1,
//         // DICTIONARY_HIDDEN_2
//     };

//     int dict_sizes[] = {
//         sizeof(DICTIONARY_HIDDEN_0)/sizeof(DICTIONARY_HIDDEN_0[0])
//         // tailles pour les autres dictionnaires
//     };

//     int nb_dicts = 1; // change si tu ajoutes d'autres dictionnaires

//     int min_errors;
//     int best = find_best_dictionary(INPUT_DATA[0], dicts, dict_sizes, nb_dicts, &min_errors);

//     printf("Meilleur dictionnaire pour la ligne 0 : %d avec %d erreurs\n", best, min_errors);

//     return 0;
// }