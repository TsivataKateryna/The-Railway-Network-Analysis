FONCTIONNEMENT DU CODE

(1) detect.c 

Ce fichier permet de détecter les mots incorrects dans une phrase. 

La fonction principale detection permet de lire un fichier input, découpe chaque ligne en mot, vérifie si ce mot est présent dans le dictionnaire et renvoit finalement les mots incorrects avec leur position.

On utilise pour cela des structures Words, Badwords et LineErrors


Fonction principale : detection(char *input_file_path, const char *dictionnaries_path, const char *output_path)

return une structure LineErrors avec tous les mots non pérsents dans le dictionnaire et leur position dans la ligne 


Fonctions importantes:

(a) parse_line(char *line, int line_size) :

permet de convertir une ligne donnée en un tableau de mots

(b) check_if_in_dict(char *word, Dictionary_t *dict) : 

permet de vérifier si un mot d'une phrase données est présente dans le dictionnaire ou non ; renvoit true si il est présent et false si il est non présent


(c)  add_wrong_word(LineErrors line_errors, BadWord bad_word) : 

permet d'ajouter une nouvelle ligne LineErrors lorsqu'on rencontre un nouveau mot incorrect 

(d) free_Words, free_BadWord, free_LineErrors : 

fonctions qui permettent d'éviter des fuites de perte de mémoire



(2) correction.c

Ce fichier permet de corriger les phrases non corrects issus du fichier detect.c

Fonction principale : correct_errors(LineErrors errors)

permet de corriger les phrases, données sous forme de LineErrors, et on écrit la phrase corrigée

Fonctions importantes : 

(a) levenshtein(const char *s1, const char *s2):

permet de calculer la distance de Levenshtein entre deux mots donnés, typiquement dans notre cas le mot incorrect issu de LineErrors et un mot du dictionnaire choisi, et renvoit cette distance 

(b) correct_word(const char* word, const char* dictionary[]): 

permet de corriger le mot incorrect donné en utilisant la distance de Levenshtein citée plus haut


(3) select_dic.c

Ce fichier permet de détecter le dictionnaire qui est le plus approprié pour une phrase donnée


Fonction principale : find_best_dictionary(const char* line, const char** dicts[], const int dict_sizes[], int nb_dicts)

permet de trouver le meilleur dictionnaire, pour une phrase donnée, sur lequel on se base pour corriger ladite phrase



























