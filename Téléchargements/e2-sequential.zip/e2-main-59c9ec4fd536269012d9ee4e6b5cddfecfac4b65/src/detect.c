#include "../headers/detect.h"
#include "../headers/common.h"
#include <stdlib.h>
#include <string.h>

/**
    @param words Words struct to free
*/
void free_Words(Words words) {
    for (int i = 0; i < words.size; i++) {
        free(words.words[i]);
    }
    free(words.words);
}

/**
    @param words Words struct with all words
    @param word char* word to add
    @return Words struct with all words + word
**/
Words add_word(Words words, char* word) {
    Words new_words;
    new_words.size = words.size + 1;
    new_words.words = malloc(sizeof(char*) * new_words.size);

    for (int word_index = 0; word_index < words.size; word_index++) {
        new_words.words[word_index] = malloc(sizeof(char) * (strlen(words.words[word_index]) + 1));
        strcpy(new_words.words[word_index], words.words[word_index]);
    }
    new_words.words[new_words.size - 1] = malloc(sizeof(char) * (strlen(word) + 1));
    strcpy(new_words.words[new_words.size - 1], word);

    free_Words(words);

    return new_words;
}

/**
  @param line pointer to the line to be parsed
  @param line_size int of the size of the line (=word count)
  @return an array to contains the line parsed in words
**/
Words parse_line(char *line, int line_size) {
    Words words;
    words.words = NULL;
    words.size = 0;
    char* word;
    char caract;
    int char_index = 0;
    int char_done = 0;

    for (int word_index = 0; word_index < line_size; word_index++) {
        word = malloc(sizeof(char) * (strlen(line)));
        caract = line[char_done];

        // for debug
        //printf("First : %c, %i | ", caract, char_done + char_index);

        while (caract != ' ' && caract != '\n' && caract != '\0' && char_index < strlen(line)) {
            word[char_index] = caract;
            char_index++;
            caract = line[char_done + char_index];
        }
        word[char_index] = '\0';

        //get useless space available
        char* final_word = malloc(sizeof(char) * (char_index + 1));
        for (int i = 0; i < char_index + 1; i++) {
            final_word[i] = word[i];
        }
        free(word);

        char_done += char_index + 1;
        char_index = 0;

        words = add_word(words, final_word);
        free(final_word);
    }

    return words;
}


/**
    @param bad_word BadWord to be freed
*/
void free_BadWord(BadWord bad_word) {
    free(bad_word.word);
}

/**
    @param line_errors LineErrors to be freed
*/
void free_LineErrors(LineErrors line_errors) {
    for (int i = 0; i < line_errors.size; i++) {
        free_BadWord(line_errors.bad_words[i]);
    }
    free(line_errors.bad_words);
}

/**
    @param line_errors LineError struct where the bad word should be added
    @param bad_word BadWord to be added
    @return the new struct with the added word
*/
LineErrors add_wrong_word(LineErrors line_errors, BadWord bad_word) {
    LineErrors new_line_errors;
    new_line_errors.size = line_errors.size + 1;
    new_line_errors.bad_words = malloc(sizeof(BadWord) * new_line_errors.size);
    new_line_errors.dict = line_errors.dict;

    for (int i = 0; i < line_errors.size; i++) {
        new_line_errors.bad_words[i].word = malloc(sizeof(char) * (strlen(line_errors.bad_words[i].word) + 1));
        strcpy(new_line_errors.bad_words[i].word, line_errors.bad_words[i].word);
        new_line_errors.bad_words[i].index = line_errors.bad_words[i].index;
    }

    new_line_errors.bad_words[new_line_errors.size - 1].word = malloc(sizeof(char) * (strlen(bad_word.word) + 1));
    strcpy(new_line_errors.bad_words[new_line_errors.size - 1].word, bad_word.word);
    new_line_errors.bad_words[new_line_errors.size - 1].index = bad_word.index;

    free_LineErrors(line_errors);
    free_BadWord(bad_word);

    return new_line_errors;
}

/**
    @param word char* containing word to check
    @param dict Dictionary_t containing all the words from dictionary
    @return bool whether the word in the dict
*/
int cmp(const void *a, const void *b) {
    return strcmp(*(const char**) a, *(const char**) b);
}
bool check_if_in_dict(const char *word, Dictionary_t *dict) {
    void *res = bsearch(&word, dict -> words, dict -> word_count, sizeof(char*), cmp);
    if (res) return true;
    return false;
}

/**
    @param 
    @return LineError struct with all the wronly written words
*/
LineErrors detection(char* line, int line_size, Dictionary_t* dict) {
    Words parsed_line;
    BadWord bad_word;
    LineErrors line_errors;
    line_errors.size = 0;
    line_errors.dict = dict;
    line_errors.bad_words = NULL;

    parsed_line = parse_line(line, line_size);
    for (int word_index = 0; word_index < parsed_line.size; word_index++) {
        if (!check_if_in_dict(parsed_line.words[word_index], dict)) {
            bad_word.word = malloc(sizeof(char) * (strlen(parsed_line.words[word_index]) + 1));
            strcpy(bad_word.word, parsed_line.words[word_index]);
            bad_word.index = word_index;
            line_errors = add_wrong_word(line_errors, bad_word);
        }
    }
    //printf("\n");

    return line_errors;
}


// int main(void) {
//     return 0;
// }